#ifndef APC_H
#define APC_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define return status values for success and failure
#define SUCCESS 0
#define FAILURE -1 

// Define a structure for a doubly linked list node (Dlist)
typedef struct node
{
    struct node *prev ;  
    int data ;          
    struct node *next ;  
} Dlist;

// Function declarations for various operations on the doubly linked list and number operations
int read_and_validate_CLA(int argc ,char *argv[]);  
// Insert data before the head of the list
int insert_before(Dlist **head, Dlist **tail, int data);  
 // Insert data after the tail of the list
int insert_after(Dlist **head, Dlist **tail, int data);
// Delete the first node from the list
int delete_first(Dlist **head, Dlist **tail);  
// Delete all nodes from the list
int delete_list(Dlist **head, Dlist **tail);   
 // Print the contents of the list
void print_list(Dlist *head); 

void print_res(Dlist *head , int flag);  
// Insert digits into linked lists for operands
void insert_digit(Dlist **head1 , Dlist **tail1 , Dlist **head2 , Dlist **tail2 , char *argv[]);  

int addition (Dlist **head1 , Dlist **tail1 , Dlist **head2 , Dlist **tail2 , Dlist **headR , Dlist **tailR);  // Perform addition of two large numbers

int subtraction (Dlist **head1 , Dlist **tail1 , Dlist **head2 , Dlist **tail2 , Dlist **headR , Dlist **tailR , char *argv[]);  // Perform subtraction of two large numbers

int multiplication (Dlist **head1 , Dlist **tail1 , Dlist **head2 , Dlist **tail2 , Dlist **headR1 , Dlist **tailR1 , Dlist **headR2 , Dlist **tailR2);  // Perform multiplication of two large numbers

int division (Dlist **head1 , Dlist **tail1 , Dlist **head2 , Dlist **tail2 , Dlist **headR , Dlist **tailR , char *argv[]);  // Perform division of two large numbers

#endif
