#include "apc.h"

// Function to multiply two large numbers represented as linked lists
int multiplication (Dlist **head1 , Dlist **tail1 , Dlist **head2 , Dlist **tail2 , Dlist **headR1 , Dlist **tailR1 , Dlist **headR2 , Dlist **tailR2)
{
    Dlist *temp1 = *tail1 ;  // Temporary pointer to traverse the first operand from the tail 
    Dlist *temp2 = *tail2 ;  // Temporary pointer to traverse the second operand  from the tail
    Dlist *backup_head = NULL ; 
    Dlist *backup_tail = NULL ;
    int num1 , num2 , carry = 0 , mul , res , count = 0;  // Variables for multiplication, carry, and result storage

    // If both numbers have only one digit, multiply them directly
    if(temp1 ->prev == NULL && temp2 -> prev == NULL)
    {
        num1 = temp1 ->data;  // Get the digit from the first operand
        num2 = temp2 -> data ;  // Get the digit from the second operand
        mul = (num1 * num2) + carry ;  // Multiply and add carry if any
        if(insert_before(headR1 , tailR1 , mul) == FAILURE)  // Insert the result in the result list 
        {
            return FAILURE; 
        } 
        print_res(*headR1 , 0);  // Print the result after multiplication
        return SUCCESS;  
    }

    // Main loop for multiplication when numbers have multiple digits
    while(temp2 != NULL)  // Loop through each digit of the second operand 
    {
        carry = 0;  // Reset carry for each new digit of temp2
        // Loop through each digit of the first operand 
        while(temp1 != NULL)
        {
            num1 = temp1 ->data;  // Get the digit from the first operand
            num2 = temp2 -> data ;  // Get the digit from the second operand
            mul = (num1 * num2) + carry ;  // Multiply the digits and add any carry
            res = mul % 10 ;  // Get the result digit
            carry = mul / 10 ;  // Calculate the new carry 

            // If it's the first pass through temp1, store the full multiplication result
            if(temp1 ->prev == NULL )
            {
                res = mul ; 
            }

            // If we're at the last digit of head2 (temp2), insert the result in headR1 
            if(temp2 == *tail2)
            {
                if(insert_before(headR1 , tailR1 , res) == FAILURE)  // Insert result at the front of headR1
                {
                    return FAILURE;  // Return failure if insertion fails
                }
            }
            else
            {
                // If not the last digit of head2, insert result in headR2 
                if(insert_before(headR2 , tailR2 , res) == FAILURE)  // Insert result in headR2
                {
                    return FAILURE;  // Return failure if insertion fails
                }   
            }
            temp1 = temp1 ->prev ;  // Move to the previous digit in head1 
        }

        // If this is not the first pass, we add trailing zeros to the result in headR2
        if(count != 0)
        {
            for(int i = 0 ; i < count ; i++)  
            {
                    insert_after(headR2 , tailR2 , 0);  // Insert zero at the end of headR2
            }
        }

        // After completing one multiplication, add the intermediate result  to the final result (headR1)
        if(addition(headR1 , tailR1 , headR2 , tailR2 ,&backup_head , &backup_tail) == SUCCESS)
        {
            // If addition is successful, update headR1 with the new result and clear headR2
            if(delete_list(headR1 , tailR1) == SUCCESS)
            {
                *headR1 = backup_head;  // Set headR1 to the result of the addition
                *tailR1 = backup_tail;  // Set tailR1 to the result of the addition
                backup_head = NULL ;  
                backup_tail = NULL ;
                delete_list(headR2 , tailR2);  // Clear the intermediate list
            }
        }

        temp1 = *tail1 ;  // Reset temp1 to the last digit of head1 for the next pass
        temp2 = temp2 -> prev ;  // Move to the previous digit in head2 
        count++ ;  
    }
    print_res(*headR1 , 0); 
    return SUCCESS; 
}