#include "apc.h"

// Function to perform subtraction of two large numbers represented as linked lists
int subtraction (Dlist **head1 , Dlist **tail1 , Dlist **head2 , Dlist **tail2 , Dlist **headR , Dlist **tailR ,char *argv[])
{
    Dlist *temp1 = *tail1; 
    Dlist *temp2 = *tail2; 
    int num1 ;  
    int num2 ;  
    int borrow = 0 , sub, size1 , size2 , flag = 0 ;  
    
    // Get the size of both input numbers (argv[1] and argv[3])
    size1 = strlen(argv[1]);
    size2 = strlen(argv[3]);
    
   
    if(size1 < size2)  // If the first number is smaller
    {
        temp1 = *tail2;  // Swap operands to ensure the larger number is first
        temp2 = *tail1 ;
        flag = 1 ; 
    }
    else if (size1 > size2)  // If the first number is larger
    {
        temp1 = *tail1; 
        temp2 = *tail2 ;
    }
    else  // If both numbers have the same size
    {
        // Compare the numbers lexicographically (as strings)
        if(strcmp(argv[1] , argv[3]) == 0)  // If both numbers are equal
        {
            // Insert a 0 into the result list (headR) as the result of subtraction is 0
            if(insert_before(headR , tailR , 0) == FAILURE)
            {
                return FAILURE ;  // Return failure if insertion fails
            }
            return SUCCESS ;  // Return success as subtraction result is zero
        }
        else if(strcmp(argv[1] , argv[3]) < 0)  // If the first number is lexicographically smaller than the second
        {
            flag = 1 ;  // Set flag to 1 to indicate the result will be negative
            temp1 = *tail2;  // Swap operands to subtract the larger number from the smaller one
            temp2 = *tail1 ;
        }
    }

    // Perform the subtraction digit by digit from the right
    while(temp1 != NULL || temp2 != NULL)
    {
        
        if(temp2 == NULL)  // If second number is exhausted, set num2 to 0
        {
            num2 = 0 ;
            num1 = temp1 -> data ;  // Get digit from the first number
            temp1 = temp1 -> prev ;  
        }
        else if(temp1 == NULL)  
        {
            num1 = 0 ;
            num2 = temp2 -> data ;  // Get digit from the second number
            temp2 = temp2 -> prev ;  // Move to the next digit of the second number
        }
        else  // Both numbers still have digits to subtract
        {
            num1 = temp1 -> data ;  
            num2 = temp2 -> data ;  
            temp1 = temp1 -> prev ;  // Move to the next digit of the first number
            temp2 = temp2 -> prev ;  // Move to the next digit of the second number
        }

       
        if (borrow == 1)
        {
            num1 = num1 - 1 ;  // Subtract 1 from num1 if there was a borrow
        }

        // Perform subtraction and handle borrowing if num1 < num2
        if (num1 < num2)
        {
            num1 = num1 + 10 ;  
            borrow = 1 ;  // Set borrow flag for the next iteration
            sub = num1 - num2 ;  // Perform the subtraction
            if(insert_before(headR , tailR , sub) == FAILURE)  // Insert the result in the result list
            {
                return FAILURE ; 
            }
        }
        else
        {
            sub = num1 - num2 ;  // Subtract num2 from num1 without borrow
            borrow = 0 ;  // Reset borrow flag
            if(insert_before(headR , tailR , sub) == FAILURE)  // Insert the result in the result list
            {
                return FAILURE ; 
            }
        }
        
    }

    // Remove leading zeros from the result (headR)
    Dlist *temp3 = *headR ;
    while( temp3 -> next != NULL)
    {
        if(temp3 -> data == 0)  // If the current digit is 0
        {
            delete_first(headR , tailR);  // Remove the leading zero
        }
        else
        {
            break ;  
        }
        temp3 = temp3 ->next ;  // Move to the next digit
    }

    return flag ;  
}
