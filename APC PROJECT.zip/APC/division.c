#include "apc.h"

// Function to perform division of two linked lists representing large numbers
int division (Dlist **head1 , Dlist **tail1 , Dlist **head2 , Dlist **tail2 , Dlist **headR , Dlist **tailR , char *argv[])
{
    // Check if the second operand is zero 
    if((*head2) ->data == 0)
    {
        printf("ERROR or Not Defined\n");  
        return -1 ; 
    }

    int count = 0 ;  // Initialize count to track how many times subtraction was performed

    while(1)  // Infinite loop, will break when division is complete
    {
        // Variables to store the sizes of both lists
        int size1 = 0 , size2 = 0 ;  
        // Temporary pointer to traverse the first linked list
        Dlist *temp3 = *head1 ;   
        // Temporary pointer to traverse the second linked list 
        Dlist *temp4 = *head2 ;  
        // Traverse the first list (head1) to count its size
        while(temp3 != NULL)
        {
            size1++ ;  
            temp3 = temp3 ->next ;  // Move to the next node
        }
        

        // Traverse the second list to count its size
        while(temp4 != NULL)
        {
            size2++ ;
            temp4 = temp4 ->next ;  // Move to the next node
        }
        

        // If the size of the first operand is smaller than the second, stop the division
        if((size1 < size2))
        {
            break ;  
        }
        // If the size of the first operand is greater than the second, perform subtraction
        else if(size1 > size2)
        {
            
            if(subtraction(head1 , tail1 ,head2 , tail2 ,headR , tailR , argv) == SUCCESS)
            {
                // If subtraction is successful, delete the original head1 and tail1 lists
                if(delete_list(head1,tail1) == SUCCESS)
                {
                    *head1 = *headR;  // Set head1 to the result of the subtraction
                    *tail1 = *tailR ;  // Set tail1 to the result of the subtraction
                    count++ ;  
                    *headR = NULL ;  
                    *tailR = NULL ;
                }
            }
        }
        // If both operands have the same size, compare them node by node
        else if(size1 == size2)
        {
            Dlist *temp1 = *head1;  // Temporary pointer to traverse head1
            Dlist *temp2 = *head2;  // Temporary pointer to traverse head2
            int i , flag = 0;  
           
            for (i = 0 ; i < size1 ; i++)
            {
                // If the current node of head1 is greater than head2, set flag to 1 (indicating head1 > head2)
                if(temp1 ->data > temp2 ->data)
                {
                    flag = 1;
                    break ;  
                }
                // If the current node values are equal, continue checking the next nodes
                else if(temp1 ->data == temp2 ->data)
                {
                    flag = 1 ;  
                }
               
                else
                {
                    flag = 0;
                    break ;  
                }
                temp1 = temp1 -> next ;  // Move to the next node in head1
                temp2 = temp2 -> next ;  // Move to the next node in head2
            }

            
            if(flag == 0)
            {
                break ;  
            }
            
            else
            {
                // Perform subtraction between head1 and head2
                if(subtraction(head1 , tail1 ,head2 , tail2 ,headR , tailR , argv) == SUCCESS)
                {
                    // If subtraction is successful, delete the original head1 and tail1 lists
                    if(delete_list(head1,tail1) == SUCCESS)
                    {
                        *head1 = *headR;  // Set head1 to the result of the subtraction
                        *tail1 = *tailR;  // Set tail1 to the result of the subtraction
                        count++ ;  
                        *headR = NULL ;  
                        *tailR = NULL ;
                    }
                }
            }
        }
    }

    return count ;
}  
