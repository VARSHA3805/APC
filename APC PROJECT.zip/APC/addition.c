#include "apc.h"

// Function to add two numbers represented by doubly linked lists
int addition (Dlist **head1 , Dlist **tail1 , Dlist **head2 , Dlist **tail2 , Dlist **headR , Dlist **tailR)
{
     // Initialize temp1 to the tail of the first list
    Dlist *temp1 = *tail1;
    // Initialize temp2 to the tail of the second list
    Dlist *temp2 = *tail2; 
    int num1; 
    int num2; 
    int carry = 0, sum, rem; 
    
    
    while(temp1 != NULL || temp2 != NULL)
    {
        if(temp2 == NULL) // If the second list is fully traversed, set num2 to 0
        {
            num2 = 0;
            num1 = temp1->data; // Set num1 to the current digit of the first list
            temp1 = temp1->prev; // Move temp1 to the previous node in the first list
        }
        else if(temp1 == NULL) // If the first list is fully traversed, set num1 to 0
        {
            num1 = 0;
            num2 = temp2->data; // Set num2 to the current digit of the second list
            temp2 = temp2->prev; // Move temp2 to the previous node in the second list
        }
        else // If both lists still have digits to add, get num1 and num2 from both lists
        {
            num1 = temp1->data;
            num2 = temp2->data;
            temp1 = temp1->prev; // Move temp1 to the previous node in the first list
            temp2 = temp2->prev; // Move temp2 to the previous node in the second list
        }
        
        sum = num1 + num2 + carry; // Calculate the sum of digits plus any carry from the previous addition
        rem = sum % 10; // Find the remainder 
        carry = sum / 10; // Update carry 
        // If both lists are fully traversed, set the final remainder without carry
        if(temp1 == NULL && temp2 == NULL)
        {
            rem = sum;
        }

        // Insert the result digit before the head of the result list
        if(insert_before(headR, tailR, rem) == FAILURE)
        {
            // Return failure if insertion fails
            return FAILURE; 
        }
        
    }

    // Remove leading zeros from the result list
    Dlist *temp3 = *headR;
    while(temp3->next != NULL)
    {
        // If the current digit is zero
        if(temp3->data == 0) 
        {
            // Delete the first node
            delete_first(headR, tailR); 
        }
        else
        {
            break; 
        }
        // Move to the next node
        temp3 = temp3->next; 
    }
    
     
    return SUCCESS; 
}
